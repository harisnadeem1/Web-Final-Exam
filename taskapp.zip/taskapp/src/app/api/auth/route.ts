import { NextRequest, NextResponse } from 'next/server';

const adminCredentials = { username: 'admin', password: 'admin123' };

export async function POST(req: NextRequest) {
  const { username, password } = await req.json();

  if (username === adminCredentials.username && password === adminCredentials.password) {
    return NextResponse.json({ success: true });
  }

  return NextResponse.json({ success: false, message: 'Invalid credentials' }, { status: 401 });
}