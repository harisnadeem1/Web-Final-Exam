import { NextRequest, NextResponse } from 'next/server';
import { connectToDB } from '@/utils/db';
import { Task } from '@/models/Task';

export async function GET() {
  await connectToDB();
  const user = 'admin'; 
  const tasks = await Task.find({ user });
  return NextResponse.json(tasks);
}

export async function POST(req: NextRequest) {
  await connectToDB();
  const { name, description, dueDate } = await req.json();
  const user = 'admin';
  const newTask = await Task.create({ user, name, description, dueDate });
  return NextResponse.json(newTask, { status: 201 });
}

export async function PUT(req: NextRequest) {
  await connectToDB();
  const { id, updateData } = await req.json();
  const updatedTask = await Task.findByIdAndUpdate(id, updateData, { new: true });
  return NextResponse.json(updatedTask);
}

export async function DELETE(req: NextRequest) {
  await connectToDB();
  const { taskId } = await req.json();
  await Task.findByIdAndDelete(taskId);
  return NextResponse.json({ message: 'Task deleted' });
}