import mongoose, { Schema, Document, Model } from 'mongoose';

interface ITask extends Document {
  user: string;
  name: string;
  description: string;
  dueDate: Date;
}


const TaskSchema: Schema<ITask> = new mongoose.Schema({
    user: { type: String, required: true },
    name: { type: String, required: true },
    description: String,
    dueDate: Date,
  });
  
  export const Task: Model<ITask> = mongoose.models.Task || mongoose.model<ITask>('Task', TaskSchema);