/* eslint-disable @typescript-eslint/no-unsafe-function-type */
/* eslint-disable @typescript-eslint/no-explicit-any */
export default function TaskList({
    tasks,
    onDelete,
    onEdit,
  }: {
    tasks: any[];
    onDelete: Function;
    onEdit: Function;
  }) {
    return (
      <div>
        {tasks.map((task) => (
          <div key={task._id} className="p-4 border mb-2 bg-white shadow">
            <h3 className="font-bold">{task.name}</h3>
            <p>{task.description}</p>
            <p>Due: {task.dueDate}</p>
            <button className="bg-yellow-500 px-2 py-1 text-white" onClick={() => onEdit(task)}>
              Edit
            </button>
            <button className="bg-red-500 px-2 py-1 text-white ml-2" onClick={() => onDelete(task._id)}>
              Delete
            </button>
          </div>
        ))}
      </div>
    );
  }