/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-function-type */
import { useState } from 'react';

export default function TaskForm({ onSave, task }: { onSave: Function; task: any }) {
  const [formData, setFormData] = useState(task || { name: '', description: '', dueDate: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col p-4 bg-gray-100 mb-4">
      <input
        className="border p-2 mb-2"
        placeholder="Task Name"
        value={formData.name}
        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
      />
      <textarea
        className="border p-2 mb-2"
        placeholder="Description"
        value={formData.description}
        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
      />
      <input
        className="border p-2 mb-2"
        type="date"
        value={formData.dueDate}
        onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
      />
      <button className="bg-green-500 text-white px-4 py-2" type="submit">
        Save Task
      </button>
    </form>
  );
}